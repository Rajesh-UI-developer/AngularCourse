import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-pipe',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './pipe.component.html',
  styleUrl: './pipe.component.scss'
})
export class PipeComponent {
  today = new Date();
  price = 1234.56;
  amount = 1234.567;
  fraction = 0.25;
  data = { name: 'John', age: 30 };

}
