import { Component } from '@angular/core';
import { TemplatedrivenComponent } from './templatedriven/templatedriven.component';

@Component({
  selector: 'app-formparent',
  standalone: true,
  imports: [TemplatedrivenComponent],
  templateUrl: './formparent.component.html',
  styleUrl: './formparent.component.scss'
})
export class FormparentComponent {

}
