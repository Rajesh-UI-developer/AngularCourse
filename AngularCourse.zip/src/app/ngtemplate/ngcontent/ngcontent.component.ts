import { Component } from '@angular/core';

@Component({
  selector: 'app-ngcontent',
  standalone: true,
  imports: [],
  templateUrl: './ngcontent.component.html',
  styleUrl: './ngcontent.component.scss'
})
export class NgcontentComponent {

}
