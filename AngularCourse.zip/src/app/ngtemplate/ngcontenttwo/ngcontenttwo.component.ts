import { Component } from '@angular/core';

@Component({
  selector: 'app-ngcontenttwo',
  standalone: true,
  imports: [],
  templateUrl: './ngcontenttwo.component.html',
  styleUrl: './ngcontenttwo.component.scss'
})
export class NgcontenttwoComponent {

}
