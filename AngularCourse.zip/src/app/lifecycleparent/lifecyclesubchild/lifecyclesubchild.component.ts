import { Component } from '@angular/core';

@Component({
  selector: 'app-lifecyclesubchild',
  standalone: true,
  imports: [],
  templateUrl: './lifecyclesubchild.component.html',
  styleUrl: './lifecyclesubchild.component.scss'
})
export class LifecyclesubchildComponent {

}
